#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "game.h"

// Global variables
TTF_Font *font = NULL;
SDL_Surface *bgImage = NULL;
Mix_Music *bgMusic = NULL;

void initSDL(SDL_Surface **screen, int *running) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        printf("SDL Initialization Error: %s\n", SDL_GetError());
        exit(1);
    }
    
    // Initialize SDL_image
    int imgFlags = IMG_INIT_PNG;
    if (!(IMG_Init(imgFlags) & imgFlags)) {
        printf("SDL_image could not initialize! Error: %s\n", IMG_GetError());
        exit(1);
    }
    
    // Create window
    *screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_HWSURFACE);
    if (!*screen) {
        printf("Video Mode Error: %s\n", SDL_GetError());
        exit(1);
    }
    
    // Initialize SDL_mixer
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printf("Audio Initialization Error: %s\n", Mix_GetError());
        exit(1);
    }
    
    // Initialize SDL_ttf
    if (TTF_Init() == -1) {
        printf("TTF_Init: %s\n", TTF_GetError());
        exit(1);
    }
    
    SDL_WM_SetCaption("Quiz Game", NULL);
    *running = 1;
}

void init_font(SDL_Surface **screen, int *running) {
    font = TTF_OpenFont("arial.ttf", 24);
    if (!font) {
        printf("Failed to load font: %s\n", TTF_GetError());
        *running = 0;
    }
}

void loadAssets() {
    // Load background image
    bgImage = IMG_Load("bgimage.png");
    if (!bgImage) {
        printf("Error loading bgimage.png: %s\n", IMG_GetError());
        printf("Current working directory: ");
        system("pwd");
        exit(1);
    }
    
    // Convert to display format for optimal performance
    SDL_Surface* optimized = SDL_DisplayFormat(bgImage);
    if (optimized) {
        SDL_FreeSurface(bgImage);
        bgImage = optimized;
    }
    
    printf("Background image loaded successfully! Dimensions: %dx%d\n", bgImage->w, bgImage->h);
    
    // Load background music
    bgMusic = Mix_LoadMUS("bgmusic.mp3");
    if (!bgMusic) {
        printf("Error loading bgmusic.mp3: %s\n", Mix_GetError());
        exit(1);
    }

    // Play music
    Mix_VolumeMusic(64); // Medium volume (0-128)
    if (Mix_PlayMusic(bgMusic, -1) == -1) {
        printf("Error playing music: %s\n", Mix_GetError());
        exit(1);
    }
}

void render_text(SDL_Surface *screen, const char *text, int x, int y, SDL_Color color) {
    SDL_Surface *text_surface = TTF_RenderText_Solid(font, text, color);
    SDL_Rect pos = {x, y, 0, 0};
    SDL_BlitSurface(text_surface, NULL, screen, &pos);
    SDL_FreeSurface(text_surface);
   }


Enigme decomposer(char ch[]) {
    Enigme E;
    int i = 0, j = 0;
    
    // Extract question (until '?')
    while (ch[i] != '\0' && ch[i] != '?') {
        E.question[j++] = ch[i++];
    }
    E.question[j] = '\0';
    i++; // Skip '?'

    // Skip spaces after question
    while (ch[i] == ' ') i++;

    // Answer A (until 'A.' or '.')
    j = 0;
    while (ch[i] != '\0' && ch[i] != '.' && !(ch[i] == 'A' && ch[i+1] == '.')) {
        E.rep1[j++] = ch[i++];
    }
    E.rep1[j] = '\0';
    
    // Skip the '.' or 'A.' prefix
    if (ch[i] == 'A' && ch[i+1] == '.') i += 2;
    else if (ch[i] == '.') i++;

    // Answer B (until 'B.' or '.')
    j = 0;
    while (ch[i] != '\0' && ch[i] != '.' && !(ch[i] == 'B' && ch[i+1] == '.')) {
        E.rep2[j++] = ch[i++];
    }
    E.rep2[j] = '\0';
    
    // Skip the '.' or 'B.' prefix
    if (ch[i] == 'B' && ch[i+1] == '.') i += 2;
    else if (ch[i] == '.') i++;

    // Answer C (until end or correct answer marker)
    j = 0;
    while (ch[i] != '\0' && ch[i] != '\n' && ch[i] != '\r' && 
           !(isupper(ch[i]) && (ch[i+1] == '\n' || ch[i+1] == '\r' || ch[i+1] == '\0'))) {
        E.rep3[j++] = ch[i++];
    }
    E.rep3[j] = '\0';

    // Find correct answer (last uppercase letter)
    int len = strlen(ch);
    while (len > 0 && (ch[len-1] == '\n' || ch[len-1] == '\r' || ch[len-1] == ' ')) {
        len--;
    }
    if (len > 0) {
        E.bonne = (ch[len-1] == 'A') ? 1 : (ch[len-1] == 'B') ? 2 : 3;
    } else {
        E.bonne = 1;
    }

    return E;
}

void initialiser_enigmes(Enigme tab[], int *nb) {
    FILE *f = fopen("enigmes.txt", "r");
    if (!f) return;

    int i = 0;
    while (!feof(f)) {
        fgets(tab[i].question, 200, f);
        fgets(tab[i].rep1, 100, f);
        fgets(tab[i].rep2, 100, f);
        fgets(tab[i].rep3, 100, f);
        fscanf(f, "%d\n", &tab[i].bonne);
        i++;
    }
    *nb = i;
    fclose(f);
}
Enigme generer_enigme(Enigme tab[], int nb, int deja_posees[]) {
    int index;
    do {
        index = rand() % nb;
    } while (deja_posees[index] == 1);

    deja_posees[index] = 1;
    return tab[index];
}
int afficher_enigme(SDL_Surface *screen, Enigme e) {
    SDL_Color white = {255, 255, 255};
    SDL_Color yellow = {255, 255, 0};
    //SDL_Color highlight = {0, 200, 255};
    SDL_Color highlight = {255, 255, 255};
    
    // Clear and redraw background
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    if (bgImage) {
        SDL_BlitSurface(bgImage, NULL, screen, NULL);
    }
    
    render_text(screen, e.question, 50, 50, white);
    
    // Render answers without duplicate letters
    int answer_y = 150;
    
    // Answer A
    char answerA[150];
    sprintf(answerA, "A. %s", e.rep1);
    render_text(screen, answerA, 100, answer_y, (e.bonne == 1) ? highlight : white);
    
    // Answer B
    answer_y += 50;
    char answerB[150];
    sprintf(answerB, "B. %s", e.rep2);
    render_text(screen, answerB, 100, answer_y, (e.bonne == 2) ? highlight : white);
    
    // Answer C
    answer_y += 50;
    char answerC[150];
    sprintf(answerC, "C. %s", e.rep3);
    render_text(screen, answerC, 100, answer_y, (e.bonne == 3) ? highlight : white);
    
    // Render instructions (bottom center)
    render_text(screen, "Press A, B or C to answer", 
               SCREEN_WIDTH/2 - 150, 
               SCREEN_HEIGHT - 100, yellow);
    
    SDL_Flip(screen);
    
    // Input handling (unchanged)
    SDL_Event event;
    while(1) {
        while(SDL_PollEvent(&event)) {
            if(event.type == SDL_QUIT) return -1;
            if(event.type == SDL_KEYDOWN) {
                if(event.key.keysym.sym == SDLK_a) return 1;
                if(event.key.keysym.sym == SDLK_b) return 2;
                if(event.key.keysym.sym == SDLK_c) return 3;
            }
        }
        SDL_Delay(10);
    }
}
void afficher_score(SDL_Surface *screen, int score, int vies) {
    SDL_Color white = {255, 255, 255};
    char score_text[50];
    sprintf(score_text, "Score: %d", score);
    render_text(screen, score_text, SCREEN_WIDTH - 300, 50, white);
    
    char lives_text[50];
    sprintf(lives_text, "Lives: %d", vies);
    render_text(screen, lives_text, SCREEN_WIDTH - 300, 100, white);
    
    SDL_Flip(screen);
}

int chrono(SDL_Surface *screen, Uint32 startTime) {
    Uint32 now = SDL_GetTicks();
    Uint32 elapsed = now - startTime;
    Uint32 remaining = 30000 - elapsed; // 30 seconds total
    
    if(remaining <= 0) {
        return 0; // Time expired
    }
    
    // Display remaining time
    SDL_Color red = {255, 0, 0};
    char time_text[50];
    sprintf(time_text, "Time: %d.%d", remaining/1000, (remaining % 1000)/100);
    render_text(screen, time_text, 100, 800, red);
    
    return 1; // Time remaining
}
void cleanUp() {
    // Free surfaces
    if (bgImage) {
        SDL_FreeSurface(bgImage);
        bgImage = NULL;
    }
    
    // Free music
    if (bgMusic) {
        Mix_FreeMusic(bgMusic);
        bgMusic = NULL;
    }
    
    // Close font
    if (font) {
        TTF_CloseFont(font);
        font = NULL;
    }
    
    // Quit subsystems
    Mix_CloseAudio();
    TTF_Quit();
    IMG_Quit();  // Quit SDL_image
    SDL_Quit();
};
