#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include "game.h"

int main() {
    SDL_Surface *screen = NULL;
    int running = 1;
    
    // Initialize systems
    initSDL(&screen, &running);
    init_font(&screen, &running);
    loadAssets();
    
    // Game initialization
    srand(time(NULL));
    Enigme enigmes[20];
    int nb_enigmes = 0;
    int deja_posees[20] = {0};
    int score = 0;
    int vies = 3;

    // Load questions
    FILE *f = fopen("enigmes.txt", "r");
    if (!f) {
        printf("Error opening enigmes.txt\n");
        cleanUp();
        return 1;
    }

    char ligne[256];
    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        enigmes[nb_enigmes++] = decomposer(ligne);
        if (nb_enigmes >= 20) break;
    }
    fclose(f);

    // Main game loop
    while (running && vies > 0 && nb_enigmes > 0) {
        // Clear and draw background
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
        if (bgImage) {
            SDL_BlitSurface(bgImage, NULL, screen, NULL);
        }
        
        // Get random question
        Enigme e = generer_enigme(enigmes, nb_enigmes, deja_posees);

        // Display question with timer
        Uint32 startTime = SDL_GetTicks();
        int answered = 0;
        int timeExpired = 0;

        while(!answered && running && !timeExpired) {
            // Redraw background and UI elements
            SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
            if (bgImage) {
                SDL_BlitSurface(bgImage, NULL, screen, NULL);
            }
            
            // Display score and timer
            afficher_score(screen, score, vies);
            timeExpired = !chrono(screen, startTime);

            // Display question (preserves background)
            int choix = afficher_enigme(screen, e);
            
            if(choix == -1) {
                running = 0;
            } else if(choix > 0) {
                answered = 1;
                
                // Show feedback
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
                if (bgImage) {
                    SDL_BlitSurface(bgImage, NULL, screen, NULL);
                }
                
                // Convert choice number to letter (1=A, 2=B, 3=C)
                char userChoice = 'A' + choix - 1;
                char correctChoice = 'A' + e.bonne - 1;
                
                if(choix == e.bonne) {
                    score++;
                    SDL_Color green = {0, 255, 0};
                    render_text(screen, "Correct!", 350, 450, green);
                } else {
                    vies--;
                    SDL_Color red = {255, 0, 0};
                    render_text(screen, "Wrong!", 350, 450, red);
                    
                    // Show correct answer
                    SDL_Color yellow = {255, 255, 0};
                    char correctMsg[50];
                    sprintf(correctMsg, "Correct was: %c", correctChoice);
                    render_text(screen, correctMsg, 350, 500, yellow);
                }
                SDL_Flip(screen);
                SDL_Delay(2000);
            }
        }

        if(!answered && timeExpired) {
            // Time's up message
            SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
            if (bgImage) {
                SDL_BlitSurface(bgImage, NULL, screen, NULL);
            }
            SDL_Color red = {255, 0, 0};
            render_text(screen, "Time's up!", 350, 450, red);
            SDL_Flip(screen);
            vies--;
            SDL_Delay(1500);
        }
    }

    // Game over screen
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    if (bgImage) {
        SDL_BlitSurface(bgImage, NULL, screen, NULL);
    }
    
    SDL_Color white = {255, 255, 255};
    char final_score[50];
    sprintf(final_score, "Final Score: %d", score);
    render_text(screen, "Game Over", SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 - 50, white);
    render_text(screen, final_score, SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2, white);
    SDL_Flip(screen);
    SDL_Delay(3000);

    cleanUp();
    return 0;
}
