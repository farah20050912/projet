#ifndef GAME_H
#define GAME_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>

#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

typedef struct {
    char question[200];
    char rep1[100];
    char rep2[100];
    char rep3[100];
    int bonne;
} Enigme;

// Global variables
extern TTF_Font *font;
extern SDL_Surface *bgImage;
extern Mix_Music *bgMusic;

// Function declarations
void initSDL(SDL_Surface **screen, int *running);
void init_font(SDL_Surface **screen, int *running);
void loadAssets();
void render_text(SDL_Surface *screen, const char *text, int x, int y, SDL_Color color);
void initialiser_enigmes(Enigme tab[], int *nb);
Enigme generer_enigme(Enigme tab[], int nb, int deja_posees[]);
int afficher_enigme(SDL_Surface *screen, Enigme e);
void afficher_score(SDL_Surface *screen, int score, int vies);
int chrono(SDL_Surface *screen, Uint32 startTime);
Enigme decomposer(char ch[]);
void cleanUp();

#endif
